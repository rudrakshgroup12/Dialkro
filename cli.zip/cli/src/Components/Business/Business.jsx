import React from "react";
import Cont from "../Business/Cont/Cont.jsx";
import Test from "./Test.jsx"
function Business() {
  return (
    <>
    {/* <Test/> */}
      {/* <BusinessCategory /> */}
      <Cont />
    </>
  );
}

export default Business;
