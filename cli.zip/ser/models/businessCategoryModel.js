// import mongoose from "mongoose";

// const category = new mongoose.Schema(
//   {
//     name: {
//       type: String,
//       required: true,
//       trim: true,
//       unique: true, // Ensure category names are unique
//     },
//     // Additional fields as needed
//   },
//   {
//     timestamps: true,
//   }
// );

// const Category = mongoose.model("Category", category);
// export default Category;
