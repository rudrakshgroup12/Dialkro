// import express from "express";
// import {
//   createCategory,
//   getCategorybyId,
//   getcategory,
//   updateCategory,
// } from "../controllers/busnesscategoryControll.js";
// import auth from "../middelware/auth.js";
// const categoryRoutes = express.Router();

// categoryRoutes.get("/category", getcategory);
// categoryRoutes.get("/category/:id", getCategorybyId);
// categoryRoutes.put("/category/:id", updateCategory);
// categoryRoutes.post("/category", createCategory);


// export default categoryRoutes;
